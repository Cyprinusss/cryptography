#ifndef WIDGET_H
#define WIDGET_H
#include <string>
#include <QWidget>
#include<iomanip>
#include<string>
#include<sstream>
#include<stdio.h>
#include<cstring>
#include<cmath>
#include <strstream>
using namespace std;
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pushButtonA_1_clicked();

    void on_pushButtonA_2_clicked();

    void on_pushButtonB_1_clicked();

    void on_pushButtonB_2_clicked();

    void on_pushButtonC_1_clicked();

    void on_pushButtonC_2_clicked();

    void on_pushButtonD_1_clicked();

    void on_pushButtonD_2_clicked();

    void on_pushButtonE_1_clicked();

    void on_pushButtonF_1_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
